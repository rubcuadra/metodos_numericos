format long
A1=[4 1 -1; 
    2 5 0; 
    3 8 9];
b1=[8; 
    5; 
    0];

A2=[3.4444 16100 -9.1; 
    1.9999 17.01 9.6; 
    1.6 5.2 1.7];
b2=[0; 
    1; 
    0];

A3=[5.8 3.2 11.24;
    4.3 3.4 9.625;
    2.5 5.2 9.625];
b3=[20.24;
    17.325;
    17.325];

A4=[4 5 2 -1;
    5 8 7 6;
    3 7 -4 -2;
    -1 6 -2 5];
b4=[3;
    2;
    0;
    1];

A5=[2.156 4.102 -2.3217 6; 
    -4.102 6 0 1.2; 
    -1 -5.7012 1.2222 0;
    6.532 7 0 -4];
b5=[18;
    6.5931
    3.4
    0];

%ANALITICOS
[x1,U1] = gausselim(A1,b1);
[x2,U2] = gausselim(A2,b2);
[x5] = GaussPP(A5,b5);
[x3] = GaussJordan(A3,b3);
[x4] = GaussJordan(A4,b4);
%ITERATIVOS
[x1j] = jacobi(A1,b1,ones(3,1),25)
[x2j] = jacobi(A2,b2,ones(3,1),25)
[x3Gs] = GaussSeidel(A3,b3)
[x4Gs] = GaussSeidel(A4,b4,ones(size(b4)))

%RespuestasAnaliticos
A_EliminacionGauss=x1
B_EliminacionGauss=x2
E_GaussPivot = x5
C_GaussJordan = x3
D_GaussJordan = x4
%RespuestasIterativos
A_Jacobi = x1j
B_Jacobi = x2j
C_GaussSeidel = x3Gs
D_GaussSeidel = x4Gs

save 'Tarea2.txt' A1 b1 A2 b2 A3 b3 A4 b4 A5 b5
save 'Tarea2.txt' -append A_EliminacionGauss B_EliminacionGauss E_GaussPivot C_GaussJordan D_GaussJordan 
save 'Tarea2.txt' -append A_Jacobi B_Jacobi C_GaussSeidel D_GaussSeidel






